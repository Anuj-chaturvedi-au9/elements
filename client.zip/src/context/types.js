export const GET_ELEMENTS = "GET_ELEMENTS";
export const SEARCH_ELEMENT = "SEARCH_ELEMENT";
export const CLEAR_ELEMENTS = "CLEAR_ELEMENTS";
export const ELEMENTS_ERROR = "ELEMENTS_ERROR";
export const SET_LOADING = "SET_LOADING";
export const OPEN_MODAL = "OPEN_MODAL";
export const CLOSE_MODAL = "CLOSE_MODAL";
