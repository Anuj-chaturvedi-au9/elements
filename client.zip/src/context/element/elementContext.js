import { createContext } from "react";

const elementContext = createContext();

export default elementContext;
