
var profileKey = [{
  PersonName: "Anuj Chaturvedi",
  PersonRole: "Full Stack developer",
  PersonBio: "Hi there!",
  PersonImg: "https://avatars.githubusercontent.com/u/67587859?s=400&u=f081a5d48c53f0a3ffebc9e502008da258cbff93&v=4",
  githublink: "https://github.com/anuj-chaturvedi-au9",
  linkedinlink: "#",
  bio: "This is Anuj Chaturvedi , Full Stack Developer and Cyber Security Enthusiast"
},
{
  PersonName: "Piyush Chaturvedi",
  PersonRole: "Full Stack Developer",
  PersonBio: "Hi there!",
  PersonImg: "https://avatars.githubusercontent.com/u/67586189?s=460&u=684474d94e01abb99e89a167413e508bb55c59cb&v=4",
  githublink: "https://github.com/piyush-chaturvedi-au9",
  linkedinlink: "#",
  bio: "Piyush is a MERN stack developer making web apps to make everyday lives easier. He's a keen learner and has an inquisitive personality which makes him want to explore new avenues whenever possible. He's currently exploring the world of machine learning."
},
];

export { profileKey };